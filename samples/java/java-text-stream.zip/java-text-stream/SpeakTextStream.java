package com.example;

import com.microsoft.cognitiveservices.speech.*;
import com.microsoft.cognitiveservices.speech.SpeechSynthesisRequest.SpeechSynthesisRequestInputType;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.net.URI;
import java.util.concurrent.Future;

/**
 * Azure Speech SDK - Text Streaming Input Example
 * 
 * This program demonstrates how to use text streaming input with the Azure
 * Speech SDK. Text is pushed incrementally to the synthesizer, allowing for
 * real-time speech synthesis as text becomes available.
 */
public class SpeakTextStream {

    // Set these values or use environment variables
    private static final String SPEECH_KEY = System.getenv("SPEECH_KEY");
    private static final String SPEECH_REGION = System.getenv("SPEECH_REGION");
    
    private static final Object consoleLock = new Object();

    public static void main(String[] args) {
        // Validate configuration
        if (SPEECH_KEY == null || SPEECH_KEY.isEmpty()) {
            System.err.println("Error: SPEECH_KEY is not set.");
            System.exit(1);
        }

        if (SPEECH_REGION == null || SPEECH_REGION.isEmpty()) {
            System.err.println("Error: SPEECH_REGION is not set.");
            System.exit(1);
        }

        System.out.println("Azure Speech SDK - Text Streaming Input");
        System.out.println("========================================");

        runTextStreamingDemo();
    }

    /**
     * Demonstrates text streaming by simulating text arriving in chunks
     */
    public static void runTextStreamingDemo() {
        System.out.println("\nText Streaming Demo");
        System.out.println("Text will be pushed in chunks, simulating real-time input...\n");

        // Sample text chunks (simulating streaming from an LLM or other source)
        String[] textChunks = {
            "Hello! ",
            "Welcome to the Azure ",
            "Speech SDK streaming demo. ",
            "This text is being sent ",
            "in small chunks, ",
            "just like it would arrive ",
            "from a large language model ",
            "or other streaming source. ",
            "The speech synthesis begins ",
            "as soon as text is available, ",
            "providing low-latency audio output."
        };

        try {
            // IMPORTANT: MUST use the websocket v2 endpoint for text streaming
            String ttsEndpoint = String.format(
                "wss://%s.tts.speech.microsoft.com/cognitiveservices/websocket/v2",
                SPEECH_REGION);
            
            System.out.println("Using endpoint: " + ttsEndpoint);
            
            // Create speech config from endpoint (not subscription)
            SpeechConfig speechConfig = SpeechConfig.fromEndpoint(new URI(ttsEndpoint));
            
            // Set subscription key
            speechConfig.setProperty(PropertyId.SpeechServiceConnection_Key, SPEECH_KEY);
            
            // Set output format
            speechConfig.setSpeechSynthesisOutputFormat(SpeechSynthesisOutputFormat.Raw24Khz16BitMonoPcm);
            
            // Set voice - using HD neural voice or standard neural voice
            String voice = "en-US-AvaMultilingualNeural";
            speechConfig.setProperty(PropertyId.SpeechServiceConnection_SynthVoice, voice);
            
            // set timeout value to bigger ones to avoid sdk cancel the request when time interval between text chunks
            speechConfig.setProperty(PropertyId.SpeechSynthesis_FrameTimeoutInterval, "10000");
            speechConfig.setProperty(PropertyId.SpeechSynthesis_RtfTimeoutThreshold, "10");

            try (SpeechSynthesizer synthesizer = new SpeechSynthesizer(speechConfig, null)) {
                
                // Create a streaming request
                SpeechSynthesisRequest request = new SpeechSynthesisRequest(SpeechSynthesisRequestInputType.TextStream);
                
                // Optional: Adjust pitch, rate, volume
                // request.setRate("0%");
                // request.setPitch("0%");
                // request.setVolume("100");

                ByteArrayOutputStream audioData = new ByteArrayOutputStream();
                
                // Start speaking asynchronously - returns immediately
                System.out.println("Starting speech synthesis...\n");
                Future<SpeechSynthesisResult> ttsTaskFuture = synthesizer.StartSpeakingRequestAsync(request);
                SpeechSynthesisResult ttsResult = ttsTaskFuture.get();
                
                // Start audio reading thread
                Thread audioThread = new Thread(() -> readAudioStream(ttsResult, audioData));
                audioThread.start();
                
                // Simulate streaming text (like GPT tokens)
                for (String chunk : textChunks) {
                    synchronized (consoleLock) {
                        System.out.print("[text: " + chunk.trim() + "] ");
                    }
                    
                    // Send text piece to TTS input stream
                    request.getInputStream().write(chunk);
                    
                    // Simulate delay between chunks
                    Thread.sleep(200);
                }
                
                // Close input stream when done
                request.getInputStream().close();
                
                synchronized (consoleLock) {
                    System.out.println("\n[TEXT STREAM END]");
                }
                
                // Wait for audio thread to complete
                audioThread.join();
                
                // Save audio to WAV file with proper header
                String outputFile = "streaming_output.wav";
                byte[] pcmData = audioData.toByteArray();
                saveAsWav(outputFile, pcmData, 24000, 16, 1);
                
                System.out.println("\nAudio saved to: " + outputFile);
                System.out.println("Total audio bytes: " + pcmData.length);
                
                // Note: Don't call request.close() here as the input stream is already closed
            }
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Saves raw PCM data as a WAV file with proper header
     */
    private static void saveAsWav(String filename, byte[] pcmData, int sampleRate, int bitsPerSample, int channels) throws Exception {
        int byteRate = sampleRate * channels * bitsPerSample / 8;
        int blockAlign = channels * bitsPerSample / 8;
        int dataSize = pcmData.length;
        int chunkSize = 36 + dataSize;
        
        try (FileOutputStream fos = new FileOutputStream(filename)) {
            // RIFF header
            fos.write("RIFF".getBytes());
            fos.write(intToLittleEndian(chunkSize));
            fos.write("WAVE".getBytes());
            
            // fmt subchunk
            fos.write("fmt ".getBytes());
            fos.write(intToLittleEndian(16));              // Subchunk1Size (16 for PCM)
            fos.write(shortToLittleEndian((short) 1));     // AudioFormat (1 = PCM)
            fos.write(shortToLittleEndian((short) channels));
            fos.write(intToLittleEndian(sampleRate));
            fos.write(intToLittleEndian(byteRate));
            fos.write(shortToLittleEndian((short) blockAlign));
            fos.write(shortToLittleEndian((short) bitsPerSample));
            
            // data subchunk
            fos.write("data".getBytes());
            fos.write(intToLittleEndian(dataSize));
            fos.write(pcmData);
        }
    }
    
    private static byte[] intToLittleEndian(int value) {
        return new byte[] {
            (byte) (value & 0xFF),
            (byte) ((value >> 8) & 0xFF),
            (byte) ((value >> 16) & 0xFF),
            (byte) ((value >> 24) & 0xFF)
        };
    }
    
    private static byte[] shortToLittleEndian(short value) {
        return new byte[] {
            (byte) (value & 0xFF),
            (byte) ((value >> 8) & 0xFF)
        };
    }

    /**
     * Reads audio data from the synthesis result stream
     */
    private static void readAudioStream(SpeechSynthesisResult ttsResult, ByteArrayOutputStream audioData) {
        try {
            AudioDataStream audioDataStream = AudioDataStream.fromResult(ttsResult);
            byte[] buffer = new byte[32000];
            long totalSize = 0;
            
            while (true) {
                long readSize = audioDataStream.readData(buffer);
                if (readSize == 0) {
                    break;
                }
                
                synchronized (consoleLock) {
                    System.out.print("[audio]");
                }
                
                totalSize += readSize;
                audioData.write(buffer, 0, (int) readSize);
            }
            
            synchronized (consoleLock) {
                System.out.println("\n[AUDIO STREAM END] Total: " + totalSize + " bytes");
            }
            
            audioDataStream.close();
        } catch (Exception e) {
            System.err.println("Error reading audio stream: " + e.getMessage());
        }
    }
}
